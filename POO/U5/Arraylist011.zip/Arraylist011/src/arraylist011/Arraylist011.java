/*
 * Enelsiguienteejemplosemuestraun ArrayList denúmerosenteros.
 */
package arraylist011;
import java.util.ArrayList;

/**
 *
 * @author jlfum
 */
public class Arraylist011 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
ArrayList<Integer> a = new ArrayList<Integer>();
a.add(18); a.add(22); a.add(-30);
System.out.println("Nº de elementos: " + a.size());
System.out.println("El elemento que hay en la posición 1 es " + a.get(1));
}

        // TODO code application logic here
    }
    

