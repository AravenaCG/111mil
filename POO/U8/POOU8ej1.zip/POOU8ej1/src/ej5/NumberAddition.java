package ej5;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class NumberAddition extends JFrame {

	private JPanel contentPane;
	private JTextField txtFirstNumber;
	private JTextField txtSecondNumber;
	private JTextField txtResult;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					NumberAddition frame = new NumberAddition();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public NumberAddition() {
		setTitle("Number Addition");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 600, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblFirstNumber = new JLabel("First Number");
		lblFirstNumber.setBounds(65, 41, 127, 15);
		contentPane.add(lblFirstNumber);
		
		JLabel lblSecondNumber = new JLabel("Second Number");
		lblSecondNumber.setBounds(65, 86, 127, 15);
		contentPane.add(lblSecondNumber);
		
		JLabel lblResult = new JLabel("Result");
		lblResult.setBounds(122, 139, 70, 15);
		contentPane.add(lblResult);
		
		txtFirstNumber = new JTextField();
		txtFirstNumber.setBounds(230, 39, 114, 19);
		contentPane.add(txtFirstNumber);
		txtFirstNumber.setColumns(10);
		
		txtSecondNumber = new JTextField();
		txtSecondNumber.setBounds(230, 84, 114, 19);
		contentPane.add(txtSecondNumber);
		txtSecondNumber.setColumns(10);
		
		txtResult = new JTextField();
		txtResult.setText("Result");
		txtResult.setBounds(230, 137, 114, 19);
		contentPane.add(txtResult);
		txtResult.setColumns(10);
		
		JButton btnAdd = new JButton("Add");
		btnAdd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int num1=0;
				int num2= 0;
				
				try {
					 num1 = Integer.parseInt(txtFirstNumber.getText()); 
					 num2 = Integer.parseInt(txtSecondNumber.getText());
					 int resultado = num1+num2;
					 
					txtResult.setText(Integer.toString(resultado));
					
				}
				catch (Exception t)
				{
					JOptionPane.showMessageDialog(
							null,"Complete con algun numero! Error: " + t.getMessage(),
							"ERROR",
							JOptionPane.INFORMATION_MESSAGE);
				}
				
				
			}
		});
		btnAdd.setBounds(122, 188, 117, 25);
		contentPane.add(btnAdd);
		
		JButton btnClear = new JButton("Clear");
		btnClear.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				txtFirstNumber.setText(null);
				txtSecondNumber.setText(null);
				txtResult.setText(null);
			}
		});
		btnClear.setBounds(270, 188, 117, 25);
		contentPane.add(btnClear);
		
		JButton btnClose = new JButton("Exit");
		btnClose.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			//JFrame.EXIT_ON_CLOSE;
				System.exit(0);
				
			}
		});
		btnClose.setBounds(184, 233, 117, 25);
		contentPane.add(btnClose);
	}

}
