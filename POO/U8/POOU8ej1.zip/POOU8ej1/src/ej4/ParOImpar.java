package ej4;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class ParOImpar extends JFrame {

	private JPanel contentPane;
	private JTextField Numero;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ParOImpar frame = new ParOImpar();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ParOImpar() {
		setTitle("Comprobar Par o Impar");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblIngreseUnNumero = new JLabel("Ingrese un Numero");
		lblIngreseUnNumero.setBounds(51, 30, 145, 15);
		contentPane.add(lblIngreseUnNumero);
		
		Numero = new JTextField();
		Numero.setBounds(240, 28, 114, 19);
		contentPane.add(Numero);
		Numero.setColumns(10);
		
		JButton btnComprobar = new JButton("Comprobar");
		btnComprobar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 
				try {
					int num = Integer.parseInt(Numero.getText()); 
					if ( num%2 != 0 )
					{
						JOptionPane.showMessageDialog(
								null,"El Numero es IMPAR" ,
								"Resultado",
								JOptionPane.INFORMATION_MESSAGE);
					}
					else
					{
						JOptionPane.showMessageDialog(
								null,"El Numero es PAR!! " ,
								"Resultado",
								JOptionPane.INFORMATION_MESSAGE);
					}
				}
				catch (Exception t)
				{
					JOptionPane.showMessageDialog(
							null,"Complete con algun numero! Error: " + t.getMessage(),
							"ERROR",
							JOptionPane.INFORMATION_MESSAGE);
				}
				
			}
		});
		btnComprobar.setBounds(151, 131, 117, 25);
		contentPane.add(btnComprobar);
	}

}
