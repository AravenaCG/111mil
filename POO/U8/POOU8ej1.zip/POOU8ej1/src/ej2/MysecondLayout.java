package ej2;

import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.BorderLayout;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class MysecondLayout {

	private JFrame frmMiSegundoLayout;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MysecondLayout window = new MysecondLayout();
					window.frmMiSegundoLayout.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public MysecondLayout() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmMiSegundoLayout = new JFrame();
		frmMiSegundoLayout.setTitle("Mi Segundo Layout");
		frmMiSegundoLayout.setBounds(100, 100, 600, 300);
		frmMiSegundoLayout.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmMiSegundoLayout.getContentPane().setLayout(null);
		
		JButton btnNewButton = new JButton("Boton 5");
		btnNewButton.setBounds(0, 0, 600, 25);
		frmMiSegundoLayout.getContentPane().add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Boton 7");
		btnNewButton_1.setBounds(0, 245, 600, 25);
		frmMiSegundoLayout.getContentPane().add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("Boton 6");
		btnNewButton_2.setBounds(0, 25, 117, 220);
		frmMiSegundoLayout.getContentPane().add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("Boton 8");
		btnNewButton_3.setBounds(483, 25, 117, 220);
		frmMiSegundoLayout.getContentPane().add(btnNewButton_3);
		
		JButton btnNewButton_4 = new JButton("Boton 0");
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton_4.setBounds(116, 25, 188, 116);
		frmMiSegundoLayout.getContentPane().add(btnNewButton_4);
		
		JButton btnNewButton_5 = new JButton("Boton 1");
		btnNewButton_5.setBounds(302, 25, 188, 116);
		frmMiSegundoLayout.getContentPane().add(btnNewButton_5);
		
		JButton btnNewButton_6 = new JButton("Boton 2");
		btnNewButton_6.setBounds(116, 134, 188, 111);
		frmMiSegundoLayout.getContentPane().add(btnNewButton_6);
		
		JButton btnBoton = new JButton("Boton 3");
		btnBoton.setBounds(302, 138, 188, 107);
		frmMiSegundoLayout.getContentPane().add(btnBoton);
	}

}
