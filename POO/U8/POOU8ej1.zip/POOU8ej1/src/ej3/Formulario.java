package ej3;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JRadioButton;
import javax.swing.JCheckBox;
import javax.swing.JTextField;
import javax.swing.JButton;

public class Formulario extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Formulario frame = new Formulario();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Formulario() {
		setTitle("Formulario");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNombre = new JLabel("Nombre");
		lblNombre.setBounds(37, 32, 70, 15);
		contentPane.add(lblNombre);
		
		JLabel lblApellido = new JLabel("Apellido");
		lblApellido.setBounds(37, 74, 70, 15);
		contentPane.add(lblApellido);
		
		JLabel lblGenero = new JLabel("Genero");
		lblGenero.setBounds(56, 157, 70, 15);
		contentPane.add(lblGenero);
		
		JRadioButton rdbtnH = new JRadioButton("H");
		rdbtnH.setBounds(137, 153, 62, 23);
		contentPane.add(rdbtnH);
		
		JRadioButton rdbtnM = new JRadioButton("M");
		rdbtnM.setBounds(239, 153, 149, 23);
		contentPane.add(rdbtnM);
		
		JCheckBox chckbxEstasDeAcuerdo = new JCheckBox("Estas de acuerdo?");
		chckbxEstasDeAcuerdo.setBounds(56, 196, 213, 23);
		contentPane.add(chckbxEstasDeAcuerdo);
		
		textField = new JTextField();
		textField.setBounds(136, 30, 114, 19);
		contentPane.add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setBounds(136, 72, 114, 19);
		contentPane.add(textField_1);
		textField_1.setColumns(10);
		
		JButton btnEnviar = new JButton("ENVIAR");
		btnEnviar.setBounds(133, 227, 117, 25);
		contentPane.add(btnEnviar);
	}
}
