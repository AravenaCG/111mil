package ej1;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class OnlyButtons {

	private JFrame frmMiPrimerLayout;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					OnlyButtons window = new OnlyButtons();
					window.frmMiPrimerLayout.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public OnlyButtons() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmMiPrimerLayout = new JFrame();
		frmMiPrimerLayout.setTitle("Mi primer Layout");
		frmMiPrimerLayout.setBounds(100, 100, 600, 300);
		frmMiPrimerLayout.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmMiPrimerLayout.getContentPane().setLayout(null);
		
		JButton btnNewButton_4 = new JButton("Boton 20");
		btnNewButton_4.setBounds(12, 209, 117, 49);
		frmMiPrimerLayout.getContentPane().add(btnNewButton_4);
		
		JButton btnBoton_15 = new JButton("Boton 15");
		btnBoton_15.setBounds(12, 153, 117, 58);
		frmMiPrimerLayout.getContentPane().add(btnBoton_15);
		
		JButton btnBoton_10 = new JButton("Boton 10");
		btnBoton_10.setBounds(12, 107, 117, 46);
		frmMiPrimerLayout.getContentPane().add(btnBoton_10);
		
		JButton btnBoton_5 = new JButton("Boton 5");
		btnBoton_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnBoton_5.setBounds(12, 62, 117, 46);
		frmMiPrimerLayout.getContentPane().add(btnBoton_5);
		
		JButton btnBoton = new JButton("Boton 0");
		btnBoton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnBoton.setBounds(12, 12, 117, 49);
		frmMiPrimerLayout.getContentPane().add(btnBoton);
		
		JButton btnBoton_20 = new JButton("Boton 21");
		btnBoton_20.setBounds(126, 209, 117, 49);
		frmMiPrimerLayout.getContentPane().add(btnBoton_20);
		
		JButton btnBoton_16 = new JButton("Boton 16");
		btnBoton_16.setBounds(126, 153, 117, 58);
		frmMiPrimerLayout.getContentPane().add(btnBoton_16);
		
		JButton btnBoton_11 = new JButton("Boton 11");
		btnBoton_11.setBounds(126, 107, 117, 46);
		frmMiPrimerLayout.getContentPane().add(btnBoton_11);
		
		JButton btnBoton_6 = new JButton("Boton 6");
		btnBoton_6.setBounds(126, 62, 117, 46);
		frmMiPrimerLayout.getContentPane().add(btnBoton_6);
		
		JButton btnBoton_1 = new JButton("Boton 1");
		btnBoton_1.setBounds(126, 12, 117, 49);
		frmMiPrimerLayout.getContentPane().add(btnBoton_1);
		
		JButton btnBoton_21 = new JButton("Boton 22");
		btnBoton_21.setBounds(238, 209, 117, 49);
		frmMiPrimerLayout.getContentPane().add(btnBoton_21);
		
		JButton btnBoton_17 = new JButton("Boton 17");
		btnBoton_17.setBounds(238, 153, 117, 58);
		frmMiPrimerLayout.getContentPane().add(btnBoton_17);
		
		JButton btnBoton_12 = new JButton("Boton 12");
		btnBoton_12.setBounds(238, 107, 117, 46);
		frmMiPrimerLayout.getContentPane().add(btnBoton_12);
		
		JButton btnBoton_7 = new JButton("Boton 7");
		btnBoton_7.setBounds(238, 62, 117, 46);
		frmMiPrimerLayout.getContentPane().add(btnBoton_7);
		
		JButton btnBoton_2 = new JButton("Boton 2");
		btnBoton_2.setBounds(238, 12, 117, 49);
		frmMiPrimerLayout.getContentPane().add(btnBoton_2);
		
		JButton btnBoton_22 = new JButton("Boton 23");
		btnBoton_22.setBounds(354, 209, 117, 49);
		frmMiPrimerLayout.getContentPane().add(btnBoton_22);
		
		JButton btnBoton_18 = new JButton("Boton 18");
		btnBoton_18.setBounds(354, 153, 117, 58);
		frmMiPrimerLayout.getContentPane().add(btnBoton_18);
		
		JButton btnBoton_13 = new JButton("Boton 13");
		btnBoton_13.setBounds(354, 107, 117, 46);
		frmMiPrimerLayout.getContentPane().add(btnBoton_13);
		
		JButton btnBoton_8 = new JButton("Boton 8");
		btnBoton_8.setBounds(354, 62, 117, 46);
		frmMiPrimerLayout.getContentPane().add(btnBoton_8);
		
		JButton btnBoton_3 = new JButton("Boton 3");
		btnBoton_3.setBounds(354, 12, 117, 49);
		frmMiPrimerLayout.getContentPane().add(btnBoton_3);
		
		JButton btnBoton_23 = new JButton("Boton 24");
		btnBoton_23.setBounds(471, 209, 117, 49);
		frmMiPrimerLayout.getContentPane().add(btnBoton_23);
		
		JButton btnBoton_19 = new JButton("Boton 19");
		btnBoton_19.setBounds(471, 153, 117, 58);
		frmMiPrimerLayout.getContentPane().add(btnBoton_19);
		
		JButton btnBoton_14 = new JButton("Boton 14");
		btnBoton_14.setBounds(471, 107, 117, 46);
		frmMiPrimerLayout.getContentPane().add(btnBoton_14);
		
		JButton btnBoton_9 = new JButton("Boton 9");
		btnBoton_9.setBounds(471, 62, 117, 46);
		frmMiPrimerLayout.getContentPane().add(btnBoton_9);
		
		JButton btnBoton_4 = new JButton("Boton 4");
		btnBoton_4.setBounds(471, 12, 117, 49);
		frmMiPrimerLayout.getContentPane().add(btnBoton_4);
	}
}
