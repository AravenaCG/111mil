package test;
import javax.swing.*;

public class pruebaGUI {

	public pruebaGUI() {
		JFrame frame = new JFrame ("Ejemplo");
		JPanel contentPane = (JPanel) frame.getContentPane();
		JLabel label = new JLabel("Etiqueta2");
		JPanel panel = new JPanel();	
		JButton boton = new JButton("Botoncito");
		panel.add(boton);
		panel.add(label);
		contentPane.add(panel);
		
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setSize(400, 1000);
		frame.setVisible(true);
		
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		javax.swing.SwingUtilities.invokeLater(new Runnable() {
			public void run () {
				pruebaGUI gui = new pruebaGUI();
			}
			
		});
	}

}
