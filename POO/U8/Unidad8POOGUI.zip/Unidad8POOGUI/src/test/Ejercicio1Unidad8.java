package test;
import javax.swing.*;


public class Ejercicio1Unidad8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String cadena = ( JOptionPane.showInputDialog(
	null,"Introduzca su nombre",
	"Nombre",
	JOptionPane.QUESTION_MESSAGE) );
		
		String cadenaInvertida = "";
		
	    for (int x=cadena.length()-1;x>=0;x--)
	    {
    		cadenaInvertida = cadenaInvertida + cadena.charAt(x);
	    }
	    
	JOptionPane.showMessageDialog(
	null,"Su nombre al reves es: " + cadenaInvertida,
	"ERBMON",
	JOptionPane.INFORMATION_MESSAGE);
	}

	}


