
public class ProbarMiExcepcion {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			int num = 10;
			int num2= 0;
			float result;
			if (num2 == 0)
			{
				throw new MiExcepcion("Probando mi MiExcepcion");
			}
			result = num/num2;
			
			System.out.println(result);
			
		}
		catch (MiExcepcion e)
		{
			System.out.println(e.getMsg());
		}
		finally
		{
			System.out.println("Pase por el finally");
		}
	}

	
}
