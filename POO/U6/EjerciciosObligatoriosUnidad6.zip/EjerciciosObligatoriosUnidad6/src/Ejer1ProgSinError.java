
public class Ejer1ProgSinError {

	
	public static float Div(int a , int b) {
		
		float answer=0;
		answer = a/b;
		
		
		return answer;
	}
	
	public static void main(String[] args) {
		
		try {
			int num = 10;
			int num2= 5;
			float result;
			result = Div(num,num2);
			System.out.println(result);
			
		}
		catch ( Exception e)
		{
			System.out.println(e.getMessage());
		}
		finally
		{
			System.out.println("Pase por el finally");
		}
	}
	
}

