
public class Ejercicio3 {

	
		public static float Div(int a , int b) {
			
			float answer=0;
			answer = a/b;
			
			
			return answer;
		}
		
		public static void main(String[] args) {
			
			try {
				int num = 10;
				int num2= 0;
				float result;
				if (num2 == 0)
				{
					throw new java.lang.Exception("No se puede dividir por 0!!!");
				}
				result = Div(num,num2);
				
				System.out.println(result);
				
			}
			catch (Exception e)
			{
				System.out.println(e.getLocalizedMessage());
			}
			finally
			{
				System.out.println("Pase por el finally");
			}
		}
		
	

	}


